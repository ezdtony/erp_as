<div id="infoEntrega" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-body p-4">
                <div class="text-center">
                    <i class="dripicons-information h1 text-info"></i>
                    <h3 class="mt-2">Información de entrega</h3>
                    <h5>Fecha de entrega</h5>
                    <h5 id="lbl_entrega_fecha"></h5>
                    <h6 id="lbl_entrega_hor"></h6>
                    <p class="mt-3" id="lbl_entrega_comentarios"></p>
                    <button type="button" class="btn btn-info my-2" data-bs-dismiss="modal">Aceptar</button>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->