<?php

require('makefont/makefont.php');

MakeFont('font\helveticab.ttf', 'cp1252');
