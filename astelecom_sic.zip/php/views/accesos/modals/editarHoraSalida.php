<div class="modal fade" id="editarHoraSalida" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="mySmallModalLabel">Editar hora de Salida</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <div class="form-floating">
                    <input type="time" class="form-control" id="hora_salida_edit" placeholder="Hora" />
                    <label for="Hora">Hora</label>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary saveEditarHora">Guardar</button>
            </div>
        </div>
    </div>
</div>