<div id="asignarUnidad" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="asignarUnidadLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="asignarUnidadLabel">Registrar unidad</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <h3>Por favor seleccione la persona a quien se le asignará esta unidad</h3>
            <div class="modal-body">
                <div class="form-floating mb-3">
                    <select class="form-control select2" data-toggle="select2" id="personalVehiculo">
                        
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cerrar</button>
                <button type="button" class="btn btn-primary btnAsignarUnidad">Guardar</button>
            </div>
        </div>
    </div>
</div>