

/* $("#div_proyecto").select2({
    dropdownParent: $("#createSolicitud"),
  });
  $("#id_dimension").select2({
    dropdownParent: $("#createSolicitud"),
  });
  $("#id_um").select2({
    dropdownParent: $("#createSolicitud"),
  }); */